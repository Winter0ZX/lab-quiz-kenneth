The purpose of this project is to learn how to create a README.md file
